<?php
if(isset($_POST['submit']))
{
$name = $_POST['name'];
$phone_no= $_POST['mobnumber'];
$email= $_POST['email'];
$event = $_POST['eventname'];
$location= $_POST['eventlocation'];
$people_count = $_POST['numberofpeople'];
$food_type= $_POST['Foodtype'];
$date= $_POST['eventdate'];
}
if (!empty($name) || !empty($phone_no) || !empty($email) || !empty($event) || !empty($location) || !empty($people_count) || !empty($food_type) || !empty($date))
 {
 $host="localhost";
  $user="root";
  $pass="";
  $db="atyoursrvice75";
$conn=mysqli_connect($host,$user,$pass,$db) or die("we couldn't connect");

$sql="insert into reservation1(name,email,phone,eventname,eventlocation,no_of_people,foodtype,eventdate) values('$name','$email', '$phone_no','$event','$location','$people_count','$food_type','$date')";

if ($conn->query($sql) === TRUE) {
    echo "<script type='text/javascript'>window.alert('Registered successfully...')</script>";
 $url='Home.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
} else {

echo "<script type='text/javascript'>window.alert(' Error: could not register please try again!!')</script>";
 $url='rese.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';}

$conn->close();

}
else
{
echo "<script type='text/javascript'>window.alert('Required fields are empty, please fill all the fields.')</script>"; $url='rese.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}
?>

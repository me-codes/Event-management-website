<?php
if(isset($_POST['submit']))
{
$name = $_POST['name'];
$email= $_POST['email'];
$message = $_POST['meassage'];
}
if (!empty($name) && !empty($email) && !empty($message))
 {
 $host="localhost";
  $user="root";
  $pass="";
  $db="atyoursrvice75";
$conn=mysqli_connect($host,$user,$pass,$db) or die("we couldn't connect");

$sql="insert into feedback(name,email,msg) values('$name','$email', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "<script type='text/javascript'>window.alert('Feedback sent successfully...')</script>";
 $url='Home.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
} else {

echo "<script type='text/javascript'>window.alert(' Error: could not register please try again!!')</script>";
 $url='cont.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';}

$conn->close();

}
else
{
echo "<script type='text/javascript'>window.alert('Required fields are empty, please fill all the fields.')</script>"; $url='cont.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}
?>

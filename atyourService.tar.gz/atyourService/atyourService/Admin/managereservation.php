<?php
 $host="localhost";
  $user="root";
  $pass="";
  $db="atyoursrvice75";
$conn=mysqli_connect($host,$user,$pass,$db) or die("we couldn't connect");

if(isset($_POST['Searchevent'])) //searches event with id 
{
$eventid = $_POST['id'];
	if (!empty($eventid))
 	{
	$sql="select * from reservation1 where eventid=$eventid;";
  	$result = mysqli_query($conn, $sql);
    
    // if id exist 
    // show data in inputs
    		if(mysqli_num_rows($result) > 0)
    		{
   		   while ($row = mysqli_fetch_array($result))
    		  {
       		$eventid =$row['eventid'];
		$name =$row['name'];
		$phone_no=$row['phone'];
		$email=$row['email'];
		$event =$row['eventname'];
		$location=$row['eventlocation'];
		$people_count =$row['no_of_people'];
		$food_type= $row['foodtype'];
		$date= $row['eventdate'];
            
 echo "<script type='text/javascript'>window.alert('Event-ID:$eventid \\n Name:$name \\n Phonenumber:$phone_no  \\n Email:$email \\n Event:$event \\n Location:$location \\n Date: $date \\n No_of_people:$people_count \\n Foodtype:$food_type')</script>";
$url='events.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
                }     }  
    
    // if the id not exist
    // show a message and clear inputs
                else {
                        echo "<script type='text/javascript'>window.alert('Wrong eventid! try again.')</script>";
 $url='events.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
  		  }
            mysqli_free_result($result);  
        }
        else
         {
          echo "<script type='text/javascript'>window.alert('Please enter the event id to search!..')</script>";
 $url='events.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
         }
}
if(isset($_POST['All_events'])) //All current events fetch
{

 $query = "SELECT * FROM reservation1";
 
 
echo '<table border="1" cellspacing="3" cellpadding="3"> 
      <tr> 
          <td> <font face="Arial">Event ID</font> </td> 
          <td> <font face="Arial">Name</font> </td> 
          <td> <font face="Arial">E-mail</font> </td> 
          <td> <font face="Arial">Mobile no</font> </td> 
          <td> <font face="Arial">EventName</font> </td>  
          <td> <font face="Arial">Location</font> </td> 
          <td> <font face="Arial">People count</font> </td> 
          <td> <font face="Arial">Food type</font> </td> 
          <td> <font face="Arial">Event Date</font> </td> 
      </tr>';
 $result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["eventid"];
        $field2name = $row["name"];
        $field3name = $row["email"];
        $field4name = $row["phone"];
        $field5name = $row["eventname"]; 
        $field6name = $row["eventlocation"];
        $field7name = $row["no_of_people"];
        $field8name = $row["foodtype"];
        $field9name = $row["eventdate"]; 
 
        echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
                  <td>'.$field3name.'</td> 
                  <td>'.$field4name.'</td> 
                  <td>'.$field5name.'</td> 
                  <td>'.$field6name.'</td> 
                  <td>'.$field7name.'</td> 
                  <td>'.$field8name.'</td> 
                  <td>'.$field9name.'</td> 
              </tr>';
    }
    $result->free();
} 

}
if(isset($_POST['Deleteevent']))//Deleteing Record
{
$eventid12 = $_POST['id'];
if (!empty($eventid12))
{

$sql="delete from reservation1 where eventid=$eventid12;";
  	$result = mysqli_query($conn, $sql);
if($result)
{
          echo "Record deleted successfully...";
 $url='events.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}
else
{
 echo "<script type='text/javascript'>window.alert('Wrong event id, Please try again..')</script>";
 $url='events.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}

}
else
{
	          echo "<script type='text/javascript'>window.alert('Please enter the event id to Delete!..')</script>";
 $url='events.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}
}


if(isset($_POST['Updeevent'])) //All current events fetch
{
 $query = "SELECT * FROM reservation1";
echo '<table border="1" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Event ID</font> </td> 
          <td> <font face="Arial">Name</font> </td> 
          <td> <font face="Arial">E-mail</font> </td> 
          <td> <font face="Arial">Mobile no</font> </td> 
          <td> <font face="Arial">EventName</font> </td>  
          <td> <font face="Arial">Location</font> </td> 
          <td> <font face="Arial">People count</font> </td> 
          <td> <font face="Arial">Food type</font> </td> 
          <td> <font face="Arial">Event Date</font> </td> 
      </tr>';
 $result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["eventid"];
        $field2name = $row["name"];
        $field3name = $row["email"];
        $field4name = $row["phone"];
        $field5name = $row["eventname"];  
        $field6name = $row["eventlocation"];
        $field7name = $row["no_of_people"];
        $field8name = $row["foodtype"];
        $field9name = $row["eventdate"]; 
 
         echo "<tr> <form action=reservation1.php method=GET>";
          echo "<td><input type=int name=eventid value='".$row['eventid']."'></td>";
            echo "<td><input type=text name=name value='".$row['name']."'></td>";
  	 echo "<td><input type=text name=email value='".$row['email']."'></td>";
  	 echo "<td><input type=int name=phone value='".$row['phone']."'></td>";
   	echo "<td><input type=text name=eventname value='".$row['eventname']."'></td>";
   	echo "<td><input type=text name=eventlocation value='".$row['eventlocation']."'></td>";
    	 echo "<td><input type=int name=no_of_people value='".$row['no_of_people']."'></td>";
   	echo "<td><input type=text name=foodtype value='".$row['foodtype']."'></td>";
  	 echo "<td><input type=date name=eventdate value='".$row['eventdate']."'></td>";
	 echo "<td><input type=submit name=submitupdt value=update></td>";
	echo "</form></tr>";
    }
    $result->free();
   } 
}

$conn->close();
?>

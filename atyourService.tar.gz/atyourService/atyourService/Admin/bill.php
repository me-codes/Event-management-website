<?php
 $host="localhost";
  $user="root";
  $pass="";
  $db="atyoursrvice75";
$conn=mysqli_connect($host,$user,$pass,$db) or die("we couldn't connect");

if(isset($_POST['createbill']))
{
$eventid = $_POST['eventid23'];
$service=$_POST['servicecharge'];
	if (!empty($eventid))
 	{
	$sql="insert into billdetails(eventid,service_charge) values('$eventid','$service')";

		if ($conn->query($sql) === TRUE) 
		{
  		  echo "<script type='text/javascript'>window.alert('Bill created successfully...')</script>";
 		$url='bills.html';
  		 echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
		}
		 else
		 {

			echo "<script type='text/javascript'>window.alert(' Error: could not create bill, please try again!!')</script>";
 			$url='bills.html';
   			echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
		 }

	}
	else
	{
	echo "<script type='text/javascript'>window.alert('Please enter event id to create bill..')</script>"; 			$url='bills.html';
        echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
	}
}

$conn->close();
?>

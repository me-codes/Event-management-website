<?php
if(isset($_GET['editfood']))
{
$host="localhost";
  $user="root";
  $pass="";
  $db="atyoursrvice75";
$conn=mysqli_connect($host,$user,$pass,$db) or die("we couldn't connect");
$foodtype23 = $_GET['foodtype1'];
$rate23 = $_GET['rate1'];
$sql="update foodtype set food_type='$foodtype23', rate='$rate23'
where food_type='$foodtype23';";
$result = mysqli_query($conn, $sql);

if($result)
{
    echo "<script type='text/javascript'>window.alert('Record updated successfully...')</script>";
 $url='manage_food.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
} 
else 
{
echo "<script type='text/javascript'>window.alert(' Error:something went wrong! please try again!!')</script>";
 $url='manage_food.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}
$conn->close();
}
?>

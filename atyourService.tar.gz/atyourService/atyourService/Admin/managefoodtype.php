<?php
 $host="localhost";
  $user="root";
  $pass="";
  $db="atyoursrvice75";
$conn=mysqli_connect($host,$user,$pass,$db) or die("we couldn't connect");
if(isset($_POST['Insertfood']))
{
$foodtype= $_POST['foodtype'];
$rate= $_POST['rate'];

	if (!empty($foodtype) && !empty($rate))
 	{
	$sql="insert into foodtype(food_type,rate) values('$foodtype','$rate')";

		if ($conn->query($sql) === TRUE) 
		{
  		  echo "<script type='text/javascript'>window.alert('food type added successfully...')</script>";
 		$url='manage_food.html';
  		 echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
		}
		 else
		 {

			echo "<script type='text/javascript'>window.alert(' Error: could not add food record, please try again!!')</script>";
 			$url='manage_food.html';
   			echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
		 }

	}
	else
	{
	echo "<script type='text/javascript'>window.alert('Required fields are empty, please fill all the fields.')</script>"; 			$url='manage_food.html';
        echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
	}
}


if(isset($_POST['Updatefood'])) //All current events fetch
{
 $query = "SELECT * FROM foodtype";
echo '<table border="1" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Food Type</font> </td> 
          <td> <font face="Arial">Rate</font> </td> 
      </tr>';
 $result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["food_type"];
        $field2name = $row["rate"];
 
         echo "<tr> <form action=updatefood.php method=GET>";
          echo "<td><input type=int name=foodtype1 value='".$row['food_type']."'></td>";
            echo "<td><input type=text name=rate1 value='".$row['rate']."'></td>";
	 echo "<td><input type=submit name=editfood value=update entry></td>";
	echo "</form></tr>";
    }
    $result->free();
   } 
}



if(isset($_POST['Deletefood']))//Deleteing Record
{
$foodtype3 = $_POST['foodtype'];
if (!empty($foodtype3))
{

$sql="delete from foodtype where food_type='$foodtype3';";
  	$result = mysqli_query($conn, $sql);
if($result)
{
echo "<script type='text/javascript'>window.alert('Record deleted successfully...')</script>";
 $url='manage_food.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}
else
{
 echo "<script type='text/javascript'>window.alert('Wrong entry, Please try again..')</script>";
 $url='manage_food.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}

}
else
{
	          echo "<script type='text/javascript'>window.alert('Please enter the foodtype to Delete!..')</script>";
 $url='manage_food.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}
}


if(isset($_POST['Showall'])) //All current events fetch
{

 $query = "SELECT * FROM foodtype";
 
 
echo '<table border="1" cellspacing="3" cellpadding="3"> 
      <tr> 
          <td> <font face="Arial">Food Type</font> </td> 
          <td> <font face="Arial">Rate</font> </td> 
      </tr>';
 $result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["food_type"];
        $field2name = $row["rate"];
 
        echo '<tr> 
                  <td>'.$field1name.'</td> 
                  <td>'.$field2name.'</td> 
              </tr>';
    }
    $result->free();
} 

}

$conn->close();
?>

<?php
if(isset($_GET['deletefeedback']))
{
$host="localhost";
  $user="root";
  $pass="";
  $db="atyoursrvice75";
$conn=mysqli_connect($host,$user,$pass,$db) or die("we couldn't connect");
$name1 = $_GET['name'];
$email1 = $_GET['email'];
$date1 = $_GET['date'];
$sql="delete from feedback where name='$name1' && email='$email1' && date='$date1';";
  	$result = mysqli_query($conn, $sql);

$result = mysqli_query($conn, $sql);

if($result)
{
    echo "<script type='text/javascript'>window.alert('Record Deleted successfully...')</script>";
} 
else 
{
echo "<script type='text/javascript'>window.alert(' Error:Something went wrong, please try again!')</script>";
 $url='feedback.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}
$conn->close();
}
?>

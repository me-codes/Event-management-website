<?php
if(isset($_GET['submitupdt']))
{
$host="localhost";
  $user="root";
  $pass="";
  $db="atyoursrvice75";
$conn=mysqli_connect($host,$user,$pass,$db) or die("we couldn't connect");
$eventid = $_GET['eventid'];
$name = $_GET['name'];
$phone_no= $_GET['phone'];
$email= $_GET['email'];
$event = $_GET['eventname'];
$location=$_GET['eventlocation'];
$people_count = $_GET['no_of_people'];
$food_type= $_GET['foodtype'];
$date= $_GET['eventdate'];


$sql="update reservation1 set name='$name', email='$email', phone='$phone_no', eventname='$event', eventlocation='$location',   no_of_people='$people_count', foodtype='$food_type', eventdate='$date'
where eventid='$eventid';";
$result = mysqli_query($conn, $sql);

if($result)
{
    echo "<script type='text/javascript'>window.alert('Record updated successfully...')</script>";
 $url='events.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
} 
else 
{
echo "<script type='text/javascript'>window.alert(' Error:something went wrong! please try again!!')</script>";
 $url='events.html';
   echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
}
$conn->close();
}
?>

<?php
 $host="localhost";
  $user="root";
  $pass="";
  $db="atyoursrvice75";
$conn=mysqli_connect($host,$user,$pass,$db) or die("we couldn't connect");


if(isset($_POST['Seefeedback'])) //All current events fetch
{

 $fromdate = $_POST['datefrom'];
$todate = $_POST['dateto'];

 $query = "SELECT * FROM feedback where date BETWEEN '$fromdate' AND '$todate';";
echo '<table border="1" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Name</font> </td> 
          <td> <font face="Arial">Email</font> </td> 
          <td> <font face="Arial">Feedback</font> </td> 
          <td> <font face="Arial">Date</font> </td> 
      </tr>';
 $result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    while ($row = $result->fetch_assoc()) {
        $field1name = $row["name"];
        $field2name = $row["email"];
        $field3name = $row["msg"];
        $field4name = $row["date"];
       
 
         echo "<tr> <form action=feedbackdel.php method=GET>";
          echo "<td><input type=int name=name value='".$row['name']."'></td>";
            echo "<td><input type=text name=email value='".$row['email']."'></td>";
  	 echo "<td><input type=text name=msg value='".$row['msg']."'></td>";
  	 echo "<td><input type=int name=date value='".$row['date']."'></td>";
echo "<td><input type=submit name=deletefeedback value=Delete></td>";
	echo "</form></tr>";
    }
    $result->free();
   } 
}
$conn->close();
?>
